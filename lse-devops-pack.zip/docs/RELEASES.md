Keep semantic version in VERSION; tag releases `git tag v$(cat VERSION)`.
