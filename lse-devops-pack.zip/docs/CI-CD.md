See Jenkinsfile for primary CI/CD. Add Jenkins credentials: dockerhub-username, dockerhub-password, kubeconfig-file.
