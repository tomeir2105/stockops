# Config Management

Edit tickers and polling in `helm/lse-stack/values.yaml` under `appConfig`.
