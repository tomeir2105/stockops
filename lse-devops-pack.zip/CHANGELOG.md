# Changelog

## [0.1.0] - 2025-08-30
- Initial DevOps scaffolding: Jenkins pipeline, Helm chart, tests, config layout.
